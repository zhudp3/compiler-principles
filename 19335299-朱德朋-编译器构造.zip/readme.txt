注意，该项目可以完成简单的加法运算；

运行词法分析部分
输入命令：
flex clang.lex
gcc -o clang.out lex.yy.c -lfl
./clang.out <text.txt

运行LL1.c来完成中间代码的生成
gcc -o demo1 LL1.c stack.c
./demo

运行asm.c来完成汇编代码生成
gcc -o asm.o asm.c
./asm.o

运行out.asm来运行汇编程序
nasm -f elf64  out.asm
ld out.o -o  out
./out