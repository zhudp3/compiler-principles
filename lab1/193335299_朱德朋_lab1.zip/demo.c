#include <stdio.h>
#define N 10000

int main()
{
	int i;
	float j,k;
	i=10;
	j=1.0;
	k=-1.2e-10;
	char x='y';
	char y='x';	
	//abcdef
	char *s="This is a Lexer designed by zhudp3!";	
	/*Q2
	*/
	return 0;
}