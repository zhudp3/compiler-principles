#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

void InitiateStack(Stack* stack){
	stack->size=0;
	stack->top=NULL;
}
void push(Stack* stack, const int value){
	if(stack!=NULL){
		node* new = (node*)malloc(sizeof(node));
		new->val=value;;
		new->next=stack->top;
		stack->top=new;
		stack->size++;
	}
}
void pop(Stack* stack){
	if(stack!=NULL){
		node* old=stack->top;
		stack->top=stack->top->next;
		free(old);
		stack->size--; 
	}
}
int empty(const Stack* stack){
	return stack->size==0;
}
int top(const Stack* stack){
	return stack->top->val;
}
int size(const Stack* stack){
	return stack->size;
}