#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"

#define MAX 100

enum state{
    algebra,open_pare,close_pare,opt1,opt2,end_tag,\
    S,AddExp1,AddExp2,MulExp1,MulExp2,Exp,epsilon=-1
};

Stack first;
int First[13][6];
Stack follow;
int Follow[6][6]={5};
int Select[9][4];
int SelectLen[9];
int Table[6][6];

int Expression[9][4]={
    {S,AddExp1,-1,-1},
    {AddExp1,MulExp1,AddExp2,-1},
    {AddExp2,opt1,MulExp1,AddExp2},
    {AddExp2,epsilon,-1,-1},
    {MulExp1,Exp,MulExp2,-1},
    {MulExp2,opt2,Exp,MulExp2},
    {MulExp2,epsilon,-1,-1},
    {Exp,open_pare,AddExp1,close_pare},
    {Exp,algebra,-1,-1}
};

int get_first(int a,int index){
    InitiateStack(&first);
    push(&first,a);
    int count=0;
    while(!empty(&first)){
        int x=top(&first);
        //printf("%d ",x);
        if(top(&first)<=5){
            First[index][count]=top(&first);
            //printf("%d ",top(&first));
            //pop(&first);
            count++;
        }
        pop(&first);
        for(int i=0;i<9;i++){
            if(Expression[i][0]==x){    
                push(&first,Expression[i][1]);
            }
            
        }
        
    }
    //printf("\n");
    return count;
}

int check(int* a,int b,int len){
    for(int i=0;i<len;i++){
        if(b==a[i])return 1;
    }
    return 0;
}

int get_follow(int a){
    if(a==S)return 1;
    int index=0;
    for(int i=0;i<9;i++){
        for(int j=1;j<4;j++){
            if(Expression[i][j]==a){
                if(j+1<4){
                    if(Expression[i][j+1]<0){
                        if(Expression[i][0]!=a){
                            int count=get_follow(Expression[i][0]);
                            // printf("%d\n",count);
                            for(int k=0;k<count;k++){
                                if(!check(&Follow[a-6],Follow[Expression[i][0]-6][k],index)){
                                    Follow[a-6][index]=Follow[Expression[i][0]-6][k];
                                    // printf("%d\n",Follow[a-6][index]);
                                    index++;
                                }
                                

                            }
                        }
                        
                    }
                    else if(Expression[i][j+1]<6){
                        Follow[a-6][index]=Expression[i][j+1];
                        index++;
                    }
                    else {
                        int count=get_first(Expression[i][j+1],Expression[i][j+1]+1);
                        for(int k=0;k<count;k++){
                            if(!check(&Follow[a-6],First[Expression[i][j+1]+1][k],index)){
                                    Follow[a-6][index]=First[Expression[i][j+1]+1][k];
                                    // printf("%d\n",Follow[a-6][index]);
                                    index++;
                            }
                        }
                        // printf("%d\n",check(&Follow[a-6],-1,index));
                        if(check(&Follow[a-6],-1,index)){
                            count=get_follow(Expression[i][0]);
                            // printf("%d\n",count);
                            for(int k=0;k<count;k++){
                                if(!check(&Follow[a-6],Follow[Expression[i][0]-6][k],index)){
                                    Follow[a-6][index]=Follow[Expression[i][0]-6][k];
                                    // printf("%d\n",Follow[a-6][index]);
                                    index++;
                                }   
                                

                            }
                        }
                    }
                }
                else if(Expression[i][0]!=a){
                    int count=get_follow(Expression[i][0]);
                    for(int k=0;k<count;k++){
                        if(!check(&Follow[a-6],Follow[Expression[i][0]-6][k],index)){
                            Follow[a-6][index]=Follow[Expression[i][0]-6][k];
                            index++;
                        }

                    }
                    
                }
            }
        }
        
    }
    
    return index;
    
}

int get_select(){
    for(int i=0;i<9;i++){
        int j;
        if(Expression[i][1]!=epsilon){
            int count=get_first(Expression[i][1],Expression[i][1]+1);
            for(j=0;j<count;j++){
                Select[i][j]=First[Expression[i][1]+1][j];
                // printf("%d ",Select[i][j]);
            }
        }
        else {
            
            int count=get_first(Expression[i][1],Expression[i][1]+1);
            for(j=0;j<count;j++){
                Select[i][j]=First[Expression[i][1]+1][j];
            }
            count=get_follow(Expression[i][0]);
            for(int k=0;k<count;k++){
                if(!check(&Select[i],Follow[Expression[i][0]-6][k],j)){
                    Select[i][j]=Follow[Expression[i][0]-6][k];
                    j++;
                }
            }

        }
        SelectLen[i]=j;
    }
    
    return 1;
}

void make_table(){
    get_select();
    for(int i=0;i<6;i++){
        for(int j=0;j<6;j++){
            Table[i][j]=-1;
        }
    }
    for(int i=0;i<9;i++){
        for(int j=0;j<SelectLen[i];j++){
            
            int x=Expression[i][0]-6;
            int y=Select[i][j];
            // printf("X:%d ",x);
            // printf("Y:%d ",Select[i][j]);
            if(y>=0){
                Table[x][y]=i;
            }
        }
        // printf("\n");
    }
    // for(int i=0;i<6;i++){
    //     for(int j=0;j<6;j++){
    //         printf("%d ",Table[i][j]);
    //     }
    //     printf("\n");
    // }
}

int check_table(int Vn,int Vt){
    return Table[Vn][Vt];
}

void back_push(Stack* stack,int num){
    for(int i=3;i>0;i--){
        if(Expression[num][i]!=-1){
            push(stack,Expression[num][i]);
            //printf("%d ",Expression[num][i]-6);
        }
    }
    //printf("\n");
}

int main(){
    FILE *fp=NULL;
    fp=fopen("token.txt","r");
    int Vt;
    Stack stack;
    int count=0;
    int seq[MAX];
    make_table();
    //printf("%d\n",get_first(Exp,Exp+1));
    while (fscanf(fp,"%d",&Vt)!=-1)
    {   
        seq[count]=Vt;
        count++;
        if(Vt==5){
            InitiateStack(&stack);
            push(&stack,end_tag);
            push(&stack,S); 
            int len=0;
                    
            while(!empty(&stack)){
                //printf("%d ",seq[len]);
                
                if(top(&stack)==seq[len]){
                    pop(&stack);
                    len++;
                }
                if(empty(&stack)){
                    printf("Correct!\n");
                    break;
                }
                int num=check_table(top(&stack)-6,seq[len]);
                //printf("%d %d ",top(&stack)-6,seq[len]);
                if(num==-1&&top(&stack)!=epsilon){
                    printf("Error!\n");
                    break;
                }
                pop(&stack);
                back_push(&stack,num);
            }
            count=0;
        }
    }
    
    return 0;
}