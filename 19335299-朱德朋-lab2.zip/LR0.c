#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"

#define MAX 100

enum state{
    algebra,open_pare,close_pare,opt1,opt2,end_tag,\
    S,AddExp,MulExp,Exp,Z
};

int table[13][10]={
    {4,5,0,0,0,0,12,1,2,3},
    {0,0,0,6,0,-1,0,0,0,0},
    {0,0,-3,-3,8,-3,0,0,0,0},
    {0,0,-5,-5,-5,-5,0,0,0,0},
    {0,0,-7,-7,-7,-7,0,0,0,0},
    {4,5,0,0,0,0,0,10,2,3},
    {4,5,0,0,0,0,0,0,7,3},
    {0,0,-2,-2,8,-2,0,0,0,0},
    {4,5,0,0,0,0,0,0,0,9},
    {0,0,-4,-4,-4,-4,0,0,0,0},
    {0,0,11,6,0,0,0,0,0,0},
    {0,0,-6,-6,-6,-6,0,0,0,0},
    {0,0,0,0,0,13,0,0,0,0}
};
int Table[13][10];

struct LR0
{
    int flag;
    int num;
    int index;//标记·的位置
    int item[8][4];
    int child[8];//标记项目下个项目集
    int parent[8];
}I[20];

int Expression[8][4]={
    {Z,S,0,0},
    {S,AddExp,0,0},
    {AddExp,AddExp,opt1,MulExp},
    {AddExp,MulExp,0,0},
    {MulExp,MulExp,opt2,Exp},
    {MulExp,Exp,0,0},
    {Exp,open_pare,AddExp,close_pare},
    {Exp,algebra,0,0}
};

int ExpLen[8]={2,2,4,2,4,2,4,2};

int check(int* a,int b,int len){
    for(int i=0;i<len;i++){
        if(b==a[i])return 1;
    }
    return 0;
}

void initiate(){
    I[0].num=1;
    I[0].index=1;
    I[0].item[0][0]=Z;
    I[0].item[0][1]=S;
    I[0].flag=1;
}

int closure(int n){ 
    Stack stack;
    InitiateStack(&stack);
    for(int i=0;i<I[n].num;i++){
        if(I[n].item[i][I[n].index]>5)
            push(&stack,I[n].item[i][I[n].index]);
    }
    int count=I[n].flag;
    while (!empty(&stack))
    {
        int x=top(&stack);
        pop(&stack);

        
        for(int i=0;i<8;i++){
                
            if(Expression[i][0]==x){
                for(int j=0;j<4;j++){
                       I[n].item[count][j]=Expression[i][j];
                }
                count++;
                if(Expression[i][1]!=x){
                    push(&stack,Expression[i][1]);
                }
                

            }
        }
        
    }
    I[n].flag=count;
    
    return count;

}

int checkINT(int a[8][4],int b[8][4]){
    for(int i=0;i<8;i++){
        for(int j=0;j<4;j++){
            if(a[i][j]!=b[i][j])return 0;
        }
    }
    return 1;
}

int gotoClosure(int n,int X){
    int Itemp[8][4]={0};
    int Inum=0;
    int Iflag=I[n].flag;
    int Iindex=I[n].index;
    Iindex++;
    for(int i=0;i<I[n].num;i++){
        int checkW=I[n].item[i][I[n].index];
        if(checkW==X&&I[n].item[i][Iindex]){
            
            for(int j=0;j<4;j++){
                Itemp[Inum][j]=I[n].item[i][j];
            }
            Inum++;
        }
    }
    Iflag=Inum;
    Stack stack;
    InitiateStack(&stack);
    for(int i=0;i<Inum;i++){
        if(Itemp[i][Iindex]>5)
            push(&stack,I[n].item[i][I[n].index]);
    }
    int count=Iflag;
    while (!empty(&stack))
    {
        int x=top(&stack);
        pop(&stack);

        
        for(int i=0;i<8;i++){
                
            if(Expression[i][0]==x){
                for(int j=0;j<4;j++){
                       Itemp[count][j]=Expression[i][j];
                }
                count++;
                if(Expression[i][1]!=x){
                    push(&stack,Expression[i][1]);
                }
                

            }
        }
        
    }
    Iflag=count;
    int already=0;
    for(int i=0;i<20;i++){
        if(I[i].flag!=0){
            if(Inum==I[i].num&&Iflag==I[i].flag&&Iindex==I[i].index&&checkINT(Itemp,I[i].item)){
                already=1;
                return 1;
            }
        }

    }
    if(already==0){
        for(int i=0;i<20;i++){
            if(I[i].flag!=0){
                I[i].num==Inum;
                I[i].flag==Iflag;
                I[i].index==Iindex;
                for(int j=0;j<8;j++){
                    for(int k=0;k<4;k++){
                        I[i].item[i][j]=Itemp[i][j];
                    }
                }
            
            }

        }
    }


}

void make_table(){
    initiate();
    closure(0);
    for(int i=S;i<Exp;i++)gotoClosure(0,i);
    gotoClosure(0,algebra);
    gotoClosure(0,open_pare);
}

int main(){
    FILE *fp=NULL;
    fp=fopen("token.txt","r");
    int Vt;
    Stack W_s;
    Stack I_s;
    InitiateStack(&W_s);
    InitiateStack(&I_s);
    int count=0;
    int seq[MAX];
    make_table();
    while (fscanf(fp,"%d",&Vt)!=-1)
    {   
        seq[count]=Vt;
        count++;
        if(Vt==5){
            InitiateStack(&W_s);
            InitiateStack(&I_s);
            push(&W_s,5);
            //push(&W_s,seq[0]);
            push(&I_s,0);
            int len=0;
            int nextW;
            int nextI;
            int rf=0;
            int checkW=seq[len];
            int checkI;
            nextW=seq[len];
            while (top(&I_s)!=13)
            {       
                nextI=table[top(&I_s)][nextW];
                //printf("%d ",top(&I_s));
                //printf("%d ",nextW);
                //printf("%d ",nextI);
                if(nextI==0){
                    printf("Error!\n");
                    break;
                }
                else if(nextI<0){
                    int nn=-nextI;
                    for(int i=1;i<ExpLen[nn];i++){
                        pop(&W_s);
                        pop(&I_s);
                    }
                    checkI=table[top(&I_s)][Expression[nn][0]];
                    //printf("%d %d\n",top(&I_s),Expression[nn][0]);
                    push(&W_s,Expression[nn][0]);
                    push(&I_s,checkI);
                    //printf("%d\n",checkI);
                    
                }
                else{
                    len++;
                    nextW=seq[len];
                    push(&W_s,nextW);
                    push(&I_s,nextI);
                }
                if(top(&I_s)==13){
                    printf("Correct!\n");
                }
            }
            
            count=0;
        }
    }
    
    return 0;
}